# Raj Kumar Baliyar Singh — GitHub Academic Portfolio

A responsive academic/research portfolio website built with:

- `index.html`
- `style.css`
- `script.js`
- `profile.jpg`

## Features

- Professional blue academic/research design
- Responsive layout for desktop, tablet and mobile
- Profile photograph
- Research interests
- Education timeline
- Complete publication list from the supplied CV
- Journal/conference publication filters
- Academic experience
- Academic responsibilities
- Subjects taught
- Faculty-development/service information
- ORCID, Google Scholar, LinkedIn, ResearchGate and DBLP links
- Scopus ID placeholder to avoid using an unverified identifier
- Mobile navigation
- No `<h1>` or `<h2>` tags
- Moderate typography suitable for an academic profile
- GitHub Pages compatible

## GitHub Pages

1. Create a GitHub repository.
2. Upload all four files to the repository root.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Select `main` and `/ (root)`.
6. Save.

## Important profile identifiers

The ORCID used in the template is:

`0000-0002-4418-3035`

The LinkedIn profile used is:

`https://in.linkedin.com/in/rajk-bs`

The Google Scholar button currently performs an author search for the exact name because a unique Scholar profile URL was not confidently established.

The Scopus Author ID is intentionally left as a placeholder because a unique verified ID could not be established from the available public sources.

## Customization

Replace the Scopus placeholder once the verified Scopus Author ID is available.

To update the profile image, replace `profile.jpg` with another image while keeping the same filename.
